---
name: proposal-generator
description: >
  Use this skill whenever a user wants to produce a customer-facing IBM Cloud solution proposal —
  even if they don't call it a "solution document." Activate for requests like "create a solution
  for my customer," "generate an architecture proposal," or "I need a full IBM Cloud design." This
  skill drives a structured workflow from raw requirements to a complete proposal: business
  requirements, functional and non-functional requirements, solution architecture, architecture
  decisions, component bill of materials with IBM Cloud profile sizing, RACI matrix, RAID log, and
  optional BC/DR and migration planning. Do not use for live account operations or standalone
  architecture questions — use cloud-architect instead.
---

# Proposal Generator

Expert IBM Cloud solution architect producing end-to-end proposal documents from raw customer
requirements. Default platform: IBM Cloud. For architecture questions without a proposal goal →
`cloud-architect`. For IaC generation → `terraform-expert`. For live account operations → use
the relevant specialist skill.

# Workflow Overview

This skill drives a **10-stage sequential workflow**. Each stage builds on the previous ones,
producing sections of a unified solution document that is assembled at the end.

| Stage | Name | Document Section | Variable | Asset Template |
|-------|------|-----------------|----------|----------------|
| 1 | Business Requirements | S1 Customer Background / S2 Business Requirements / S3 Solution Requirements | `[S1]` | `assets/stage1-business-requirements.md` |
| 2 | FR/NFR Extraction | S3 Detailed FR/NFR tables | `[S2]` | `assets/stage2-fr-nfr.md` |
| 3 | Solution Architecture | S4 Proposed Solution Architecture | `[S3]` | `assets/stage3-solution-architecture.md` |
| 4 | Architecture Diagram | S4 Diagram Placeholder (verbatim, no variable) | — | `assets/stage4-diagram-placeholder.md` |
| 5 | Architecture Decisions | S4 Architecture Decision table | `[S4]` | `assets/stage5-architecture-decisions.md` |
| 6 | Component BOM | S5 Solution Components & Quantities | — | `assets/stage6-bom.md` |
| 7 | RACI Matrix | S6 Appendix — RACI Matrix | — | `assets/stage7-raci-matrix.md` |
| 8 | References | S7 References | — | `assets/stage8-references.md` |
| 9 | RAID Log | S8 Appendix — RAID Log | — | `assets/stage9-raid-log.md` |
| 10 | BC/DR & Migration | S8 Appendix — BC/DR (conditional) | — | `assets/stage10-bcdr-migration.md` |

Use `update_todo_list` to track progress through stages.

---

# Prerequisites

Before starting, lead a professional, interactive discovery session with the user to gather all necessary technical and business requirements to design a robust IBM Cloud architecture. 

Load `assets/stage0-requirement-gathering.md` as the template and gather information across the all the domains. 

---

## Stage 1 — Business Requirements

Capture WHAT the business needs and WHY — not HOW.

### Logic Rules

- **Business** = Outcomes, Goals, Risks, Regulatory (the "What" and "Why")
- **Technical** = Architectures, Sizing, Tools (the "How") — extract only the *business intent*
  behind technical details; omit technical details that have no stated business intent
- **Platform accuracy**:
  - x86 workloads → use "Virtual Machines", "Containers", or "Bare Metal"
  - Power Virtual Server workloads → use "LPARs"
  - **NEVER** associate LPARs with x86
- Do NOT assume or fabricate details not present in the requirements

### Output — S1

Load `assets/stage1-business-requirements.md` as the template. Populate each section from the
customer requirements:
- **Section 1** — single paragraph identifying the customer, their industry, and context
- **Section 2** — 2-3 lines on core business drivers (NOT technical details)
- **Section 3** — one sub-section per identified requirement domain; omit any domain with no evidence

Store this output as **[S1]** for use in Stage 2.

---

## Stage 2 — FR/NFR Extraction

Classify requirements into Functional (FR) and Non-Functional (NFR).

### Classification Rules

| Classification | Definition | Test |
|---|---|---|
| FR | WHAT the system does (capabilities, workflows, integrations) | e.g. "Ingest sensor data from on-premises systems" |
| NFR | HOW the system operates (quality, constraints) | e.g. "System must achieve 99.9% availability" |

**Always NFR**: security, compliance, availability, performance, scalability, resiliency,
observability, backup, data protection, cost
**Always FR**: data ingestion, transformation, processing, integration, workflow logic

**Sources** — at least one **Recommended** (IBM best practice) and one **Derived** (logically
implied) must be present alongside Customer-stated ones:

| Source | Meaning |
|---|---|
| Customer | Explicitly stated in requirements |
| Recommended | Proposed by IBM as per best practices |
| Derived | Logically implied from functional or non-functional aspects |

**Filtering rules**:
- Exclude deprecated services: Cloud Foundry, LogDNA
- Exclude specific non-IBM product names and non-IBM clouds (AWS, Azure, GCP)
- PowerVS networking differs from VPC — treat VPC-PowerVS integration as distinct

### Output — S2

Load `assets/stage2-fr-nfr.md` as the template. Populate FR and NFR tables with sequential IDs
(FR1, FR2 … / NFR1, NFR2 …). Include at least one Customer, one Recommended, and one Derived
entry per table. Store output as **[S2]**.

---

## Stage 3 — Solution Architecture

Understand requirements first, design second.

### Design Process (follow in order)

1. Interpret intent — Lift-and-shift (default), Replatform, Modernisation, or Greenfield
2. Identify constraints — Platform (PowerVS / x86 / SAP / ROKS / IKS / VPC), regions, NFRs
3. Identify exclusions — capabilities NOT in [S2] are excluded by default
4. Validate feasibility — if a requirement cannot be satisfied on IBM Cloud, state it explicitly
5. **Only after steps 1–4**, proceed to solution design

Invoke the **cloud-architect** skill for architecture depth on:
- IBM Cloud service selection and decision trees
- Multi-zone VPC and network foundation design
- Account structure and enterprise landing zones
- Security, encryption, and compliance posture
- Well-Architected pillar review
- IaC and deployable architecture guidance
- Hybrid / multi-cloud patterns

### Scope Gate — CRITICAL

This is a **minimum viable solution**, not a reference architecture. Accuracy > Completeness.

**Exclude unless explicitly in [S2]**:
DR, HA, Automation, Observability, Security services, Hybrid connectivity (VPN / Direct Link /
Transit Gateway), Containers / OpenShift / Kubernetes, Data platforms / AI / Watson / Cloud Pak,
Satellite

**Core rules**:
- Read requirements exactly — NO assumptions, NO inferences
- NO deprecated services or invented features
- HA / DR / Backup are **distinct**: HA = intra-site redundancy, DR = site-level failover,
  Backup = point-in-time. If DR is excluded, include NO replication / failover / RPO / RTO language
- Every component **must map to a requirement ID** — if there is no traceability, exclude it
- Use `web_search` to validate IBM Cloud service existence only — NOT to generate new components

### Output — S3

Load `assets/stage3-solution-architecture.md` as the template. Every component entry **must
include a Traceability line** mapping it to FR/NFR IDs from [S2]. Only include domains and
components that have requirement traceability. Store output as **[S3]**.

---

## Stage 4 — Architecture Diagram Placeholder

Load `assets/stage4-diagram-placeholder.md` and output its contents verbatim.

---

## Stage 5 — Architecture Decisions

Document component selection rationale.

### Rules

- Only IBM Cloud services and IBM-managed offerings — exclude AWS, Azure, GCP, OCI
- Read [S3] exactly — do NOT assume, infer, or fabricate
- One row per unique IBM Cloud component from [S3]
- Use `web_search` to validate IBM service alternatives (query:
  `"Architecture Decision <component_1> <component_2>"`); if search fails, continue silently
- Do NOT add new components based solely on search output

### Output — S4

Load `assets/stage5-architecture-decisions.md` as the template. Store output as **[S4]**.

---

## Stage 6 — Component BOM

Produce the bill of materials from all components in [S3] and [S4].

### Rules

- Include **ALL** components from [S3] and [S4] — no exceptions, no omissions
- Quantity must reflect what was designed — do not guess or extrapolate
- Populate the **Profile** column using the decision logic in
  [`references/ibm-cloud-profiles.md`](references/ibm-cloud-profiles.md)

### Profile Selection Summary

| Component type | Profile format |
|---|---|
| VSI | `<family>-<vCPU>x<RAM_GB>` e.g. `bx2-4x16` — see profiles reference for family selection |
| Bare Metal (VPC) | `bx2d-metal-96x384` etc. — use `web_search "IBM Cloud Bare Metal VPC profiles"` to confirm region availability |
| IKS / ROKS worker | `<family>.<vCPU>x<RAM_GB>` e.g. `bx2.4x16` — default `bx2.4x16` unless workload demands otherwise |
| PowerVS LPAR | `<system-type> / <cores> cores <mode> / <RAM> GB` e.g. `e980 / 4 cores dedicated / 256 GB` |
| Block Storage | `general-purpose` / `5iops-tier` / `10iops-tier` / `custom` — see profiles reference |
| File Storage (VPC) | `dp2 / <capacity_GB> GB / <IOPS> IOPS` |
| Object Storage | `COS — <storage-class>` e.g. `COS — Standard` |
| Managed Database | `Standard / <vCPU> vCPU / <RAM> GB / <storage> GB`; default `Standard / 2 vCPU / 4 GB / 20 GB` |
| Services with no hardware profile | `N/A` (Transit Gateway, Load Balancer, Key Protect, SCC, etc.) |
| Sizing not determinable | `TBD — sizing required` |

IBM Cloud profile catalogues evolve. If the requirement references a specific region, use
`web_search "IBM Cloud VSI profiles <region>"` to confirm availability — once per component type,
not once per row.

For the full profile catalogue and sizing formulas, load
[`references/ibm-cloud-profiles.md`](references/ibm-cloud-profiles.md).
Key sections: VSI profiles (line 14), Bare Metal (71), IKS/ROKS (87), PowerVS (115),
Block Storage (149), File Storage (179), COS (205), Databases (219).

To price the completed BOM, use the **billing-manager** skill or the
[IBM Cloud Cost Estimator](https://cloud.ibm.com/estimator).

### Output — S6

Load `assets/stage6-bom.md` as the template. Include ALL components — no omissions.

---

## Stage 7 — RACI Matrix

Generate a complete RACI matrix for solution delivery.

### Rules

- Minimum **20 tasks** across all phases
- Every task must have at least one **R** and exactly one **A**
- No multi-code combinations per cell (e.g., "R, A" is not valid — assign the stronger role)
- **Standard phases** (use when user has not specified): Design, Build, Configure, Migrate, Deploy, Operate
- Generate 2-3 specific, actionable tasks per phase aligned with [S4] components
- Party columns: **Client | Business Partner | IBM Cloud**

**Default role patterns**:

| Activity | IBM Cloud | Client | Business Partner |
|---|---|---|---|
| Infrastructure provisioning | R, A | I | I |
| Architecture design | R | C | C |
| Requirements definition | I | R, A | C |
| UAT | C | R, A | I |
| Go-live approval | C | A | C |
| Day-to-day operations | R, A | I | I |

### Output — S7

Load `assets/stage7-raci-matrix.md` as the template. Replace every placeholder with real,
solution-specific tasks aligned to [S4] components. Minimum 20 tasks total.

---

## Stage 8 — References

Generate IBM Cloud documentation links for all solution components.

From [S3], identify all unique IBM Cloud services. For each, run **exactly one** `web_search`
(query: `"IBM Cloud <component name> documentation"`); prefer `cloud.ibm.com/docs` URLs. No
retries — skip any component where the first search returns nothing. Sort results alphabetically.

Load `assets/stage8-references.md` as the template.

---

## Stage 9 — RAID Log

Produce a focused, actionable RAID log.

### Core Principles

- Evidence-based only — extract from [S2] and [S3] exclusively; do NOT fabricate
- Every entry must be **specific to this solution** and **actionable**
- Quality over quantity: 3-5 well-identified entries per category beats 10 generic ones
- Empty categories are acceptable

### Category Definitions

| Category | Include if… |
|---|---|
| Risk | Potential future problem directly tied to a technology, integration, or constraint in this solution |
| Assumption | The solution design relies on a condition not explicitly stated in requirements |
| Issue | A current known problem **explicitly mentioned** in input that is blocking progress |
| Dependency | External prerequisite **explicitly mentioned**, outside the project team's direct control |

**Quality filter** — before including any entry, verify all four:
1. Does it reference specific technologies/systems/constraints from the input?
2. Can someone take concrete action on it?
3. Would it actually impact project success, timeline, or budget?
4. Is it specific to THIS solution (not every cloud project)?

Group entries in this order: Risks → Assumptions → Issues → Dependencies. Within each group,
sort High → Medium → Low.

### Output — S9

Load `assets/stage9-raid-log.md` as the template. Empty categories are acceptable.

---

## Stage 10 — Backup, DR & Migration (Conditional)

**Condition**: Generate this stage **only** if [S4] contains explicit mention of Backup,
Disaster Recovery, or Migration requirements. If none are present, skip entirely.

### Rules

- Read [S2] and [S4] only — do NOT assume, infer, or fabricate
- Generate a sub-section (Backup / DR / Migration) **only** if requirements explicitly reference it
- Summarise first, then elaborate with architecture overview and detailed plan

For sub-section content guidance:

**Backup**: tools and technologies (IBM Cloud Backup, Veeam, Commvault), frequency, schedule,
scope, retention, encryption, compliance, monitoring, test-restore cadence.

**Disaster Recovery**: primary/secondary site architecture, replication topology
(synchronous/asynchronous, active-active/active-passive), network connectivity (Direct Link, VPN,
Transit Gateway), RTO/RPO targets, failover/fallback, testing.

**Migration**: source and target architecture, pathway, tools (IBM Cloud Migration Services,
RackWare, etc.), network connectivity, hybrid/interim architecture, readiness assessment,
execution waves, post-migration validation.

Delegate tool-specific depth to specialist skills: `powervs-specialist` (Cobalt Iron, Veeam on
Power), `vmware-vcf-specialist` (Zerto, Veeam on VMware), `terraform-expert` (Schematics-based
DR automation).

### Output — S10

Load `assets/stage10-bcdr-migration.md` as the template. Include **only** the sub-sections that
have explicit requirements in [S4]. Omit sub-sections with no evidence.

---

# Iterative Workflow

After each stage: mark complete in `update_todo_list`, present output to the user, and wait for
feedback before proceeding. If a stage is revised, re-run all downstream stages that depend on it
(see chain below).

**Dependency chain**:

```
Raw Requirements
  └─ [S1] Stage 1: Business Requirements
       └─ [S2] Stage 2: FR/NFR Extraction
            └─ [S3] Stage 3: Solution Architecture
                 ├─ Stage 4: Diagram placeholder (no downstream deps)
                 ├─ [S4] Stage 5: Architecture Decisions
                 │    ├─ Stage 6: Component BOM        (uses S3 + S4)
                 │    ├─ Stage 7: RACI Matrix           (uses S4)
                 │    └─ Stage 10: BC/DR & Migration    (conditional, uses S2 + S4)
                 ├─ Stage 8: References                 (uses S3)
                 └─ Stage 9: RAID Log                   (uses S2 + S3)
```

---

# Final Assembly

After all stages are complete, assemble the full document in this section order:

1. S1–3 Customer Background, Business Requirements, Solution Requirements ([S1])
2. S3 Detailed FR/NFR Requirements ([S2])
3. S4 Proposed Solution Architecture + Diagram Placeholder ([S3] + Stage 4)
4. S5 Solution Components & Quantities (Stage 6)
5. S6 Appendix: RACI Matrix (Stage 7)
6. S7 References (Stage 8)
7. S8 Appendix: RAID Log (Stage 9), BC/DR & Migration (Stage 10, if applicable)

Offer to save using `write_file` with filename:
`ibm-cloud-solution-<customer-name>-<YYYY-MM-DD>.md`

---

# Rules

## MUST DO
- Follow the stage sequence — each stage feeds the next
- Present each section to the user after generation, before proceeding
- Accept user feedback and regenerate sections as needed
- Trace every solution component back to a requirement ID
- Use IBM Cloud services only
- Keep Markdown valid: balanced tags, fenced code blocks with language labels, proper table alignment

## MUST NOT DO
- Fabricate or infer requirements not explicitly stated
- Add DR / HA / security / observability components unless explicitly required
- Recommend deprecated services (Cloud Foundry, LogDNA)
- Build a solution on VMWare
- Associate LPARs with x86 workloads
- Conflate HA, DR, and Backup — they are distinct concerns
- Mix PowerVS networking with VPC networking (they are separate network fabrics)
- Proceed past prerequisites without actual customer requirements


# IBM Cloud Profile Reference

Catalogue of IBM Cloud component profiles, flavors, and sizing tiers for use during BOM generation
in Stage 7 of the ibmcloud-solutioner skill. Use this file to select the best-fit profile for each
solution component.

> **Currency note**: Profile catalogues evolve. Before finalising a BOM, validate availability with
> `ibmcloud is instance-profiles` (VSI), `ibmcloud ks flavor ls` (IKS/ROKS), or
> `ibmcloud pi system-pools` (PowerVS). Use `web_search` as a fallback for regions where CLI access
> is unavailable.

---

## 1. VSI (Virtual Server Instance) Profiles — VPC

### Profile Families

| Family | Code | vCPU:RAM ratio | Best for |
|---|---|---|---|
| Balanced | `bx2` | 1:4 | Web servers, app servers, API gateways, general workloads |
| Balanced with instance storage | `bx2d` | 1:4 | Same as bx2 + local NVMe temp storage |
| Compute | `cx2` | 1:2 | CPU-intensive: batch jobs, video encoding, HPC, CI/CD agents |
| Compute with instance storage | `cx2d` | 1:2 | Same as cx2 + local NVMe |
| Memory | `mx2` | 1:8 | Databases, caching (Redis/Memcached), analytics, ERP |
| Memory with instance storage | `mx2d` | 1:8 | Same as mx2 + local NVMe |
| Very High Memory | `vx2` | 1:14 | SAP HANA scale-up, large in-memory databases |
| Ultra High Memory | `ux2` | 1:28 | Extreme in-memory workloads (>1 TB RAM requirements) |
| GPU (V100) | `gx2` | varies | AI/ML training, GPU rendering, CUDA workloads |
| GPU (A100) | `gx3` | varies | AI/ML inference, large model training |

### Common Profile Sizes

| Profile | vCPU | RAM (GB) | Typical use case |
|---|---|---|---|
| `bx2-2x8` | 2 | 8 | Dev/test, small web server |
| `bx2-4x16` | 4 | 16 | Small app server, API server |
| `bx2-8x32` | 8 | 32 | Mid-tier app server |
| `bx2-16x64` | 16 | 64 | Large app server, small DB |
| `bx2-32x128` | 32 | 128 | Large general workload |
| `cx2-4x8` | 4 | 8 | CPU-heavy app, build agent |
| `cx2-8x16` | 8 | 16 | Batch processing |
| `cx2-16x32` | 16 | 32 | HPC, scientific compute |
| `mx2-4x32` | 4 | 32 | Small database, Redis |
| `mx2-8x64` | 8 | 64 | Mid-size database |
| `mx2-16x128` | 16 | 128 | Large database, caching cluster |
| `mx2-32x256` | 32 | 256 | Very large database |
| `vx2-4x56` | 4 | 56 | SAP HANA dev/test |
| `vx2-8x112` | 8 | 112 | SAP HANA small production |
| `vx2-16x224` | 16 | 224 | SAP HANA medium production |

### Profile Selection Decision Tree

```
What is the primary workload driver?
├── General / unspecified        → bx2  (start with bx2-2x8, scale up as needed)
├── CPU-bound                    → cx2  (start with cx2-4x8)
├── Memory-bound / database      → mx2  (start with mx2-4x32)
├── SAP HANA / large in-memory  → vx2  (start with vx2-4x56)
├── >1 TB RAM required           → ux2
├── Local NVMe temp storage      → add 'd' suffix to chosen family (bx2d, cx2d, mx2d)
└── GPU / AI-ML                  → gx2 (V100) or gx3 (A100)
```

**CLI command to list all available profiles in a region:**
```bash
ibmcloud is instance-profiles --output json | jq '[.[] | {name, vcpu:.vcpu_count.value, memory:.memory.value}]'
```

---

## 2. Bare Metal Server Profiles — VPC

IBM Cloud Bare Metal for VPC uses fixed profiles with local NVMe storage.

| Profile | vCPU | RAM (GB) | Local Storage | Best for |
|---|---|---|---|---|
| `bx2d-metal-96x384` | 96 | 384 | NVMe | High-performance compute |
| `bx2d-metal-192x768` | 192 | 768 | NVMe | Very large workloads |
| `cx2d-metal-96x192` | 96 | 192 | NVMe | CPU-intensive bare metal |
| `mx2d-metal-96x768` | 96 | 768 | NVMe | Memory-intensive bare metal |

> Bare metal availability is region-specific. Always confirm with
> `ibmcloud is bare-metal-server-profiles` before committing to a profile.

---

## 3. IKS / ROKS Worker Node Flavors

Worker node flavors follow the same VSI family naming convention with a dot separator instead of
a dash: `<family>.<vCPU>x<RAM>`.

| Flavor | vCPU | RAM (GB) | Best for |
|---|---|---|---|
| `bx2.2x8` | 2 | 8 | Dev/test clusters |
| `bx2.4x16` | 4 | 16 | General-purpose production (default recommendation) |
| `bx2.8x32` | 8 | 32 | Medium workload clusters |
| `bx2.16x64` | 16 | 64 | Large workload clusters |
| `cx2.4x8` | 4 | 8 | CPU-bound containerised workloads |
| `cx2.8x16` | 8 | 16 | Compute-intensive containers |
| `mx2.4x32` | 4 | 32 | Memory-intensive containers, stateful sets |
| `mx2.8x64` | 8 | 64 | Large in-memory containerised DBs |

**CLI command to list available flavors for a zone:**
```bash
ibmcloud ks flavor ls --provider vpc-gen2 --zone us-south-1
```

**Guidance**:
- Default cluster recommendation: `bx2.4x16` × 3 workers (one per zone for multi-zone HA)
- For data-heavy workloads, prefer `mx2` flavors to reduce pod evictions
- For CI/CD node pools, `cx2` flavors are cost-effective

---

## 4. Power Virtual Server (PowerVS) — System Types

PowerVS does not use named profiles. Sizing is expressed as system type + processor allocation mode
+ explicit core count + explicit RAM.

### System Types

| System Type | Generation | Max Cores | Max RAM | Best for |
|---|---|---|---|---|
| `s922` | Power9 | 15 | 942 GB | IBM i ERP, smaller AIX workloads |
| `e980` | Power9 | 143 | 15 TB | Large AIX/Oracle DBs, SAP HANA scale-up (≤6 TB) |
| `s1022` | Power10 | 34 | 880 GB | IBM i with Power10 performance, mid-tier AIX |
| `e1080` | Power10 | 240 | 64 TB | Largest HANA scale-up, very large Oracle DBs |

### Processor Allocation Modes

| Mode | CLI value | Behaviour | When to use |
|---|---|---|---|
| Shared uncapped | `shared` | Can burst beyond entitlement | Dev/test, variable workloads — lowest cost |
| Shared capped | `shared-capped` | Hard-capped at entitlement | Predictable CPU without bursting |
| Dedicated | `dedicated` | Exclusive physical cores | SAP HANA production (required for SAP certification) |

### BOM Expression Format for PowerVS

Express PowerVS LPARs in the Profile column as:
`<system-type> / <cores> cores <mode> / <RAM> GB`

Examples:
- `e980 / 4 cores dedicated / 256 GB` — SAP HANA production LPAR
- `s1022 / 2 cores shared / 32 GB` — IBM i dev/test LPAR
- `e1080 / 8 cores dedicated / 512 GB` — Large Oracle DB LPAR

---

## 5. Block Storage Profiles — VPC

VPC block storage profiles are **tiered by IOPS density**. The correct profile depends on the
expected I/O pattern of the workload the volume supports.

| Profile | IOPS/GB | Max IOPS | Max Capacity | Cost tier | Best for |
|---|---|---|---|---|---|
| `general-purpose` | 3 | 16 000 | 16 000 GB | $ | Boot disks, OS volumes, light workloads |
| `5iops-tier` | 5 | 48 000 | 16 000 GB | $$ | Application data, moderate I/O, web content |
| `10iops-tier` | 10 | 48 000 | 16 000 GB | $$$ | Transactional databases, high-throughput apps |
| `custom` | Variable | 48 000 | 16 000 GB | $$$+ | Specific IOPS target stated in NFRs |

### Block Storage Selection Rules

```
What workload is this volume attached to?
├── Boot disk / OS / general files     → general-purpose
├── Application data / web content     → 5iops-tier
├── Database (PostgreSQL, MySQL, etc.) → 10iops-tier
├── High-performance DB (OLTP)         → 10iops-tier or custom
└── Specific IOPS in NFR (e.g., NFR3)  → custom  (set IOPS = NFR target)
```

**IOPS calculation for sizing**:
- `general-purpose`: IOPS = GB × 3 (e.g., 500 GB → 1 500 IOPS)
- `5iops-tier`: IOPS = GB × 5 (e.g., 500 GB → 2 500 IOPS, capped at 48 000)
- `10iops-tier`: IOPS = GB × 10 (e.g., 500 GB → 5 000 IOPS, capped at 48 000)

---

## 6. File Storage Profiles — VPC File Shares

VPC file shares (NFS-based) use a single current-generation profile.

| Profile | IOPS range | Capacity range | Notes |
|---|---|---|---|
| `dp2` | 100–96 000 IOPS | 10–32 000 GB | Current generation — use for all new deployments |
| `sdp` (legacy) | 100–48 000 IOPS | 10–32 000 GB | Older profile — migrate to `dp2` |

### File Share Sizing Formula

`IOPS = min(96 000, max(100, capacity_GB × 3))`

**BOM expression**: `dp2 / <capacity_GB> GB / <IOPS> IOPS`

Example: a 1 000 GB share → `dp2 / 1000 GB / 3000 IOPS`

**CLI command to list file share profiles:**
```bash
ibmcloud is share-profiles
```

---

## 7. Object Storage (COS) — Storage Classes

IBM Cloud Object Storage has no compute profile. Select a storage **class** based on access
frequency.

| Class | Access pattern | Min storage duration | Retrieval fee | Best for |
|---|---|---|---|---|
| `Standard` | Frequent (daily) | None | None | Active data, backups accessed regularly |
| `Vault` | Infrequent (≤1×/month) | 30 days | Yes | Monthly reports, infrequent archives |
| `Cold Vault` | Rare (≤1×/year) | 90 days | Yes | Compliance archives, cold DR copies |
| `Smart Tier` | Mixed / unpredictable | None | None | Variable access patterns, automatic tiering |

**BOM expression**: `COS — <class>` (e.g., `COS — Standard`, `COS — Smart Tier`)

---

## 8. IBM Cloud Databases (ICD) — Plans and Sizing

ICD services (PostgreSQL, MySQL, MongoDB, Redis, Elasticsearch, RabbitMQ, etcd) use a **Standard**
plan with configurable resource allocation.

### Standard Plan Resource Sizing

| Size tier | vCPU | RAM (GB) | Storage (GB) | Typical use |
|---|---|---|---|---|
| Minimal | 1 | 1 | 5 | Dev/test |
| Small | 2 | 4 | 20 | Small production |
| Medium | 4 | 8 | 100 | Mid-size production |
| Large | 8 | 16 | 500 | Large production |
| X-Large | 16 | 32 | 1 000 | Very large production |

**BOM expression**: `Standard / <vCPU> vCPU / <RAM> GB / <storage> GB`
Example: `Standard / 4 vCPU / 8 GB / 100 GB`

Default when no sizing is stated: `Standard / 2 vCPU / 4 GB / 20 GB`

### Db2 on Cloud Plans

| Plan | Description |
|---|---|
| `Standard` | Single-tenant, moderate workloads |
| `Enterprise` | Single-tenant, high-performance, BYOK encryption |

---

## 9. Components with No Selectable Profile

The following IBM Cloud services do not expose a named hardware profile. Enter `N/A` in the Profile
column for these:

| Component category | Examples |
|---|---|
| Networking | Transit Gateway, VPN Gateway, Direct Link, Public Gateway, Floating IP |
| Load balancing | Application Load Balancer, Network Load Balancer |
| Security services | Key Protect, Secrets Manager, Security & Compliance Center (SCC) |
| Messaging / eventing | Event Notifications, Event Streams (use plan instead) |
| Serverless | IBM Cloud Functions, Code Engine (use plan/instance-size instead) |
| Observability | IBM Cloud Logs, IBM Cloud Monitoring, Activity Tracker |
| IAM / governance | IAM, Resource Groups, CBR, Trusted Profiles |

---

## 10. Profile Search Commands — Quick Reference

```bash
# VSI profiles
ibmcloud is instance-profiles

# VSI profile detail
ibmcloud is instance-profile bx2-4x16

# Block storage profiles
ibmcloud is volume-profiles

# File share profiles
ibmcloud is share-profiles

# Bare metal profiles (VPC)
ibmcloud is bare-metal-server-profiles

# IKS/ROKS worker node flavors
ibmcloud ks flavor ls --provider vpc-gen2 --zone <zone>

# PowerVS system types
ibmcloud pi system-pools
```

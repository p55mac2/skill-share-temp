### Risks, Assumptions, Issues and Dependencies (RAID)
The RAID log documents potential problems and key assumptions to be tracked throughout the
solution lifecycle.

| Category   | Description | Impact | Mitigation / Resolution Strategy |
| ---------- | ----------- | ------ | -------------------------------- |
| Risk       | [specific risk tied to a technology, integration, or constraint in this solution] | High   | [concrete action] |
| Risk       | [specific risk]  | Medium | [concrete action] |
| Assumption | [condition the solution design relies on that is not explicitly stated in requirements] | High   | [validation strategy] |
| Assumption | [specific assumption] | Medium | [validation strategy] |
| Issue      | [current known problem explicitly mentioned in input that is blocking progress] | High   | [resolution] |
| Dependency | [external prerequisite explicitly mentioned, outside the project team's direct control] | High   | [management strategy] |

> **Quality filter** — before including any entry, verify all four:
> 1. Does it reference specific technologies/systems/constraints from the input?
> 2. Can someone take concrete action on it?
> 3. Would it actually impact project success, timeline, or budget?
> 4. Is it specific to THIS solution (not every cloud project)?
>
> **Ordering:** group in this order: all Risks → all Assumptions → all Issues → all Dependencies.
> Within each group, sort High → Medium → Low.
>
> **Empty categories are acceptable** — no entries is better than weak generic entries.
>
> **Source**: Extract from [S2] FR/NFR tables and [S3] solution architecture only.
> Do NOT fabricate entries not grounded in the input.

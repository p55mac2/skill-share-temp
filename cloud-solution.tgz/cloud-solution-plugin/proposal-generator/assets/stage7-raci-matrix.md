## 7. Appendices

### RACI Matrix
The RACI matrix clarifies roles and responsibilities across the solution delivery lifecycle.

**RACI Legend:**
- **R (Responsible)** — performs the task
- **A (Accountable)** — owns the outcome (exactly one per task)
- **C (Consulted)** — input sought (two-way communication)
- **I (Informed)** — kept updated (one-way communication)

| Phase     | Task                                              | Client | Business Partner | IBM Cloud |
| --------- | ------------------------------------------------- | ------ | ---------------- | --------- |
| Design    | Define business requirements and success criteria | A      | C                | I         |
| Design    | Design solution architecture                      | C      | C                | R         |
| Design    | [task aligned to solution components]             | ...    | ...              | ...       |
| Build     | Provision IBM Cloud infrastructure                | I      | I                | R         |
| Build     | Configure networking and security policies        | C      | C                | R         |
| Build     | [task aligned to solution components]             | ...    | ...              | ...       |
| Configure | Configure application environments                | R      | C                | I         |
| Configure | Integrate with existing systems / identity        | R      | C                | C         |
| Configure | [task aligned to solution components]             | ...    | ...              | ...       |
| Migrate   | Execute data migration plan                       | R      | C                | C         |
| Migrate   | Validate migrated workloads                       | A      | C                | I         |
| Migrate   | [task aligned to solution components]             | ...    | ...              | ...       |
| Deploy    | Perform production deployment                     | C      | C                | R         |
| Deploy    | Conduct go-live readiness review                  | A      | C                | C         |
| Deploy    | [task aligned to solution components]             | ...    | ...              | ...       |
| Operate   | Day-to-day cloud infrastructure operations        | I      | I                | R         |
| Operate   | Monitor performance and availability              | C      | I                | R         |
| Operate   | Manage IAM and access policies                    | A      | I                | C         |
| Operate   | Incident response and escalation                  | C      | I                | R         |
| Operate   | [task aligned to solution components]             | ...    | ...              | ...       |

> Minimum 20 tasks required. Expand each phase with 2-3 specific, actionable tasks aligned to the
> solution components in Stage 7. Every task must have at least one R and exactly one A.
> No multi-code combinations per cell (e.g., "R, A" is not permitted — assign the stronger role).

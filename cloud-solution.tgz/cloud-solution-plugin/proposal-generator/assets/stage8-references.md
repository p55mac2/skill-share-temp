## 8. References

> Links are sourced from IBM Cloud documentation (cloud.ibm.com/docs). Each entry maps to a unique
> IBM Cloud service or product used in the Proposed Solution Architecture (Section 4).
> Sorted alphabetically by title.

- [Component Title](https://cloud.ibm.com/docs/...)
- [Another Component](https://cloud.ibm.com/docs/...)
- [IBM Cloud Architecture Center](https://cloud.ibm.com/docs)
- [IBM Cloud Cost Estimator](https://cloud.ibm.com/estimator)
- [IBM Cloud Well-Architected Framework](https://cloud.ibm.com/docs/architecture-framework)

> **Process:** For each unique IBM Cloud service in the solution, call `web_search` exactly once
> with query `"IBM Cloud <component name> documentation"`. Use the most relevant `cloud.ibm.com/docs`
> result. Skip components where no documentation link is found after one search.
> Do NOT retry failed searches or use alternative queries.

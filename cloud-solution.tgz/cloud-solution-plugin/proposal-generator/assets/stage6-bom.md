## 6. Solution Components & Quantities
Comprehensive list of all components required to build the proposed solution.
For cost and pricing, refer to the [Cost Estimator](https://cloud.ibm.com/estimator).

| Component | Description | Profile | Quantity |
| --------- | ----------- | ------- | -------- |
| [name]    | [brief description] | [profile or N/A] | [qty] |
| [name]    | [brief description] | [profile or N/A] | [qty] |
| [name]    | [brief description] | [profile or N/A] | [qty] |

> **Profile guidance:**
> - VSI: `<family>-<vCPU>x<RAM_GB>` e.g. `bx2-4x16`
> - IKS/ROKS worker: `<family>.<vCPU>x<RAM_GB>` e.g. `bx2.4x16`
> - PowerVS LPAR: `<system-type> / <cores> cores / <RAM> GB` e.g. `e980 / 4 cores dedicated / 256 GB`
> - Services with no hardware profile (Load Balancer, Key Protect, Transit Gateway, etc.): `N/A`
> - Sizing not determinable from requirements: `TBD — sizing required`

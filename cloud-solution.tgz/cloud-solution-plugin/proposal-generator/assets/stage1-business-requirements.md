## 1. Customer Background
[A single paragraph describing who the customer is and their context]

## 2. Business Requirements
[2-3 lines summarising the core business drivers]

## 3. Solution Requirements

### Infrastructure Modernization & Migration
[5-6 line summary]
- [requirement]
- [requirement]

### Business Continuity & Disaster Recovery (BC/DR)
[5-6 line summary]
- [requirement]

### Security & Connectivity
[5-6 line summary]
- [requirement]

### Workload Capacity Support
[5-6 line summary]
- [requirement]

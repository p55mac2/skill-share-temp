# Stage 0 – Requirement Gathering

** DO NOT ** Provide a list but a guided approach for the user to answer these.

### 1. Business Context & Goals
- Primary objective of the solution.
- Success criteria (How do we know it works?).
- Timeline/Deadlines.
- Budgetary constraints or pricing model preferences (Pay-as-you-go vs. Subscription).

### 2. Workload Profile
- Application type (Monolith, Microservices, Serverless).
- Expected traffic patterns (Average/Peak requests per second).
- Statefulness (Stateless vs. Stateful).
- Data residency requirements (Which regions/countries?).

### 3. Technical Stack
- **Compute:** (e.g., Code Engine, OpenShift, VPC VSIs, PowerVS).
- **Storage:** (e.g., Block, File, Object Storage, Managed Databases).
- **Networking:** (e.g., Public/Private endpoints, Transit Gateway, Direct Link, VPN).
- **Integration:** (e.g., Event Notifications, MQ, API Connect).

### 4. Non-Functional Requirements (NFRs)
- **Availability:** (e.g., Single-zone, Multi-zone, Multi-region).
- **Scalability:** (Auto-scaling triggers and limits).
- **Security:** (e.g., IAM roles, Secrets Manager, Key Protect, CBR rules).
- **Compliance:** (e.g., HIPAA, PCI-DSS, SOC2).
- **Backup/DR:** (RPO/RTO targets).

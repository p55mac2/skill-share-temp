### Detailed Functional Requirements
A functional requirement defines a specific behaviour, function, or action the system must perform.

| ID  | Requirement Description | Requested By |
| --- | ----------------------- | ------------ |
| FR1 | ...                     | Customer     |
| FR2 | ...                     | Recommended  |
| FR3 | ...                     | Derived      |

### Detailed Non-Functional Requirements
A non-functional requirement describes how the system performs a function.

| ID   | Requirement Description | Requested By |
| ---- | ----------------------- | ------------ |
| NFR1 | ...                     | Customer     |
| NFR2 | ...                     | Derived      |
| NFR3 | ...                     | Recommended  |

> **Notes:**
> * FR = Functional Requirement; NFR = Non-Functional Requirement
> * Recommended = Proposed by IBM as per best practices
> * Derived = Derived from functional and non-functional aspects

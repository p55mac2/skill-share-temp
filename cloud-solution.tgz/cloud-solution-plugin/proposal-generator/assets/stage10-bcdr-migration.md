## 9. Appendices (continued)

> **Condition**: Include only the sub-sections (Backup / Disaster Recovery / Migration) for which
> the Architecture Decisions ([S5]) contain explicit requirements. Omit any sub-section entirely
> if not referenced. Do NOT infer or auto-complete from headings alone.

### Operational: Backup
[Summary paragraph — objectives, scope, and key backup characteristics]

**Architecture Overview:**
- Backup tools and technologies (IBM Cloud Backup, Veeam, Commvault, etc.)
- Backup scope (which workloads / data stores are covered)
- Network topology for backup traffic

**Detailed Plan:**
- Backup frequency and schedule
- Retention policy (e.g., daily 30 days, weekly 12 months, monthly 7 years)
- Encryption at rest and in transit
- Compliance requirements addressed
- Monitoring and test-restore cadence

---

### Operational: Disaster Recovery
[Summary paragraph — DR objectives, RTO/RPO targets, and site strategy]

**Architecture Overview:**
- Primary and secondary site architecture
- Replication topology (synchronous / asynchronous, active-active / active-passive)
- Network connectivity between sites (Direct Link, VPN, Transit Gateway)

**Detailed Plan:**
- RTO target: [value]
- RPO target: [value]
- Failover procedure and automation (IBM Cloud Schematics, scripts, etc.)
- Fallback / failback procedure
- DR testing cadence and success criteria

---

### Operational: Migration
[Summary paragraph — migration objectives, source/target environments, and approach]

**Architecture Overview:**
- Source environment (current state — platform, workloads, connectivity)
- Target environment (IBM Cloud — region, services, connectivity)
- Migration tools (IBM Cloud Migration Services, RackWare RMM, Lift, etc.)
- Hybrid / interim architecture during migration window

**Detailed Plan:**
- Readiness assessment checklist
- Pre-migration tasks (network setup, IAM, landing zone, data sync)
- Migration waves and sequencing
- Cutover procedure and rollback plan
- Post-migration validation and acceptance criteria

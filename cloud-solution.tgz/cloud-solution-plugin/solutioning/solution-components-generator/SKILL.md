---
name: solution-components-generator
description: >
  Use this skill when a user supplies requirements and asks for a solution architecture, a
  component mapping, or a traceability table — even when they don't mention a requirements file
  by name. Produces the "Proposed Solution Architecture" section of an IBM Cloud solution document:
  a Solution Summary plus IBM Cloud components grouped by domain, each traced to requirement IDs and
  shown with the options considered and the reason it was selected.
  Accepts any requirements source (requirements.md from requirements-gatherer, Functional/Non-Functional
  tables, an RFP extract, or discovery notes), verifies the input holds enough to design from, then
  produces the section. For gathering or formalising requirements first, defer to requirements-gatherer.
  For open-ended architecture questions, design reviews, or landing zone guidance, defer to cloud-architect.
---

# Solution Architecture Generator

Produces the **Proposed Solution Architecture** section from a requirements file, using the
best-practice guidance of `cloud-architect`. The result is a minimum viable, fully traceable design:
accuracy over completeness.

## Skill Dispatch

| Request | Skill to Use |
|---|---|
| Gather, clarify, or formalize requirements; produce `requirements.md` | `requirements-gatherer` |
| Open-ended architecture design, service selection, landing zones, design review | `cloud-architect` |
| Terraform authoring and provisioning | `ibm-cloud-terraform` |

## Reference Routing Table

| Topic | File | Load when |
|---|---|---|
| Readiness check: required topics, verdict rules, gap questions | `references/input-readiness.md` | Step 2 |
| Output template for the requirements index (embedded in the final report) | `assets/requirements-index-output.md` | Step 3 |
| Output template for Section 4 | `assets/solution-components-output.md` | Step 4 |

## Tools

- `read_file` — load the requirements input and the reference or asset files.
- `update_todo_list` — track the workflow steps.
- `run_subagent` — consult `cloud-architect` for service selection and pattern guidance.
- `web_search` — confirm an IBM Cloud service exists and is current.
- `write_file` — save `solution-architecture.md` to the workspace.

---

## Workflow

### Step 1 — Load the requirements input

1. Take the input from the user's message: a file path, an attachment, or pasted text. Any readable
   format works; the `requirements.md` from `requirements-gatherer` is one common source with no
   special status.
2. When several files are supplied, load all of them and treat them as one combined input.
3. When no input is supplied, ask the user for the file path or content, and suggest
   `requirements-gatherer` for building one.
4. Load each file with `read_file`. When a file is empty or unreadable, report that and ask for
   another source.

### Step 2 — Verify the input holds enough to design from

Load `references/input-readiness.md` and run the readiness check on the loaded content.

1. Search for each **required** topic (workload and platform, target region, functional need, and a
   quantified non-functional target). Record status `Found`, `Partial`, or `Missing`, the value, and
   the source excerpt.
2. Treat unfilled template placeholders (such as `[e.g. ...]`), `TBD`, and blank fields as `Missing`.
3. Record **optional** topics (DR, backup, security, observability, hybrid connectivity, and so on) as
   `Found` or `Not stated`. A `Not stated` topic stays out of the design.
4. Show the user the readiness table and verdict:
   - `READY` — continue to Step 3.
   - `READY WITH GAPS` — ask one gap question per turn for each `Partial` topic, then re-evaluate.
   - `NOT READY` — ask the user for the missing content or a richer file, and resume at Step 2 with
     the new content. Hold Steps 3-5 until the verdict is `READY` or `READY WITH GAPS` with the
     user's agreement to proceed.
5. Record the user's answers as `Customer` statements in the combined input.

### Step 3 — Index the requirements for traceability

1. When the input already carries requirement IDs (for example `FR1`, `NFR3`), use them unchanged.
2. When it does not, assign sequential IDs to each `Found` topic: `FR1`, `FR2` ... for what the
   system does (workloads, storage, integration, connectivity, migration) and `NFR1`, `NFR2` ... for
   how it operates (availability, DR, backup, performance, security, compliance, observability,
   cost, region). Keep the quantified values.
3. Load `assets/requirements-index-output.md` and fill it with the index (`ID | Requirement | Source`),
   functional and non-functional requirements in separate tables. Show it to the user as the
   traceability basis. This **requirements index** is the only list of IDs that components may cite
   in Step 4.

### Step 4 — Design the solution

Understand requirements first, design second.

**STOP** here and request that the output from the previous step looks accurate and complete.  Once confirmation
proceed to execution.

1. Run the design process in order:
   1. Interpret intent: Lift-and-Shift (default), Replatform, Modernisation, or Greenfield.
   2. Identify constraints: platform (PowerVS / x86 / SAP / ROKS / IKS / VPC), regions, NFRs.
   3. Identify exclusions: capabilities not in the requirements index are excluded by default.
   4. Validate feasibility: state explicitly any requirement IBM Cloud cannot satisfy.
   5. Only after items 1-4, proceed to solution design.
2. Apply the **Scope Gate** below.
3. Consult `cloud-architect` for the options and the recommended service per component. Run the
   calls sequentially, one per domain set (compute and data, then network and security):

    run_subagent(
      profile: "advanced",
      request: "Using the cloud-architect skill, for each requirement below return: (1) every
                current IBM Cloud service or deployment option that could fulfil it, (2) the
                recommended option, (3) one line on why the recommended option fits the requirement,
                (4) one line per other option on why it was not chosen, and (5) the matching IBM
                Cloud pattern or reference architecture URL. Requirements: <paste the requirements
                index rows for the domain set>. Platform: <x86 | PowerVS | ROKS | IKS | VPC>.
                Region: <region>."
    )

   Use the returned options as input to the design. When the subagent returns a status other than
   success, continue with `web_search` for the affected components.
4. Apply the Scope Gate to the returned options: drop any option that is deprecated, sits in the
   exclusions list, or depends on a capability absent from the requirements index. Use `web_search`
   only to confirm each remaining option exists and is current.
5. For each component, select one option and write the selection rationale against the requirement
   it satisfies (quote the quantified value, such as a region, size, or availability target). Record
   every other remaining option with the reason it was not chosen. When only one current IBM Cloud
   service meets the requirement, write `None - only option meeting <ID>` in the options cell.
6. In `assets/solution-components-output.md`, place the confirmed requirements index (all functional
   and non-functional requirements, unchanged) between the Solution Summary and the components
   table. Then fill the components table: one row per selected component, with the Domain, IBM Cloud
   Component, Options Considered, Selection Rationale, Details, and Traceability columns. Write each
   cell on a single line with no line breaks. The Traceability cell lists IDs from the requirements
   index. Include only rows that have traceability, and repeat the Domain value on every row of that
   domain.
7. Write the **Solution Summary** last, naming every IBM Cloud product used and the key components.
8. Run the traceability check: every component lists at least one ID, a rationale, and its options
   (or the `None - only option` entry), and each ID in the requirements index appears under a
   component or is reported to the user as unmapped with its reason.

### Step 5 — Review, save, and hand off

1. Present the section to the user and accept feedback; regenerate as needed.
2. Save the approved section with `write_file` as `solution-architecture.md` in the same directory
   as the first requirements file, or the workspace root for pasted input.
3. Confirm the write: `read_file` the saved file and verify the
   `## 4. Proposed Solution Architecture` heading is present and that `### Requirements Index`
   appears before `### Proposed IBM Solution Components`. When the file is missing, truncated, or
   out of order, retry once and then report the error to the user.
4. Tell the user where the file was saved and offer to revise any component or domain.

---

## Scope Gate

This is a minimum viable solution, not a reference architecture.

### Exclusions

Exclude the following unless explicitly present in the requirements index:
DR, HA, Automation, Observability, Security services,
Hybrid connectivity (VPN / Direct Link / Transit Gateway), Containers / OpenShift / Kubernetes,
Data platforms / AI / Watson / Cloud Pak, Satellite.

Additional rules:
- Read requirements exactly: no assumptions, no inferences.
- Use current IBM Cloud services only; leave out deprecated services (Cloud Foundry, LogDNA) and non-IBM clouds.
- Keep HA, DR, and Backup distinct: HA is intra-site redundancy, DR is site-level failover, Backup is point-in-time. When DR is excluded, write no replication, failover, RPO, or RTO language.
- Map every component to a requirement ID; a component without traceability is left out.
- Use `web_search` to validate service existence only, not to generate new components. Options
  considered come from `cloud-architect` and stay within the same scope rules as the selected component.
- Keep Markdown valid: balanced headings, aligned tables, fenced code blocks with language labels.

### Naming Conventions

- Use "Virtual Machines", "Containers", or "Bare Metal" for x86 workloads and "LPARs" for Power Virtual Server workloads.
- Keep PowerVS networking and VPC networking separate; describe VPC-to-PowerVS integration as its own component.
- For VMware sources, design on VPC Virtual Servers, OpenShift Virtualization, or VPC Bare Metal.

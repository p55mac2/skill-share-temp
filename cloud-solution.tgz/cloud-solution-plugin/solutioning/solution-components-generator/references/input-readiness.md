# Input Readiness Check

## Table of Contents

1. [Purpose](#1-purpose)
2. [Required topics](#2-required-topics)
3. [Optional topics](#3-optional-topics)
4. [Status values](#4-status-values)
5. [Verdict rules](#5-verdict-rules)
6. [Readiness table format](#6-readiness-table-format)
7. [Gap questions](#7-gap-questions)

---

## 1. Purpose

The skill accepts any requirements file, so the content decides whether a design can be built.
Run this check right after loading the input and before indexing requirements. Search by meaning,
not by heading: a fact may sit under any heading, in prose, or in a table.

---

## 2. Required topics

All four must be `Found` before design starts.

| # | Topic | What counts as Found | Example evidence |
|---|---|---|---|
| R1 | Workload and platform | A named workload or system plus its platform (x86 VMs, containers, bare metal, Power LPAR) or a stated greenfield application type | "Order portal on x86 VMs" |
| R2 | Target region | A specific IBM Cloud region, or a country or geography that selects one | "eu-de", "Frankfurt", "data stays in Germany" |
| R3 | Functional need | At least one capability, workflow, integration, or migration goal | "Ingest sensor data from on-premises" |
| R4 | Quantified non-functional target | At least one measurable target: availability %, RTO/RPO, capacity, IOPS, throughput, latency, retention, or a named compliance framework | "99.95% uptime", "PCI-DSS v4.0" |

---

## 3. Optional topics

Record each as `Found` or `Not stated`. A `Not stated` topic stays out of the design.

| Topic | Examples |
|---|---|
| Transformation approach | Greenfield, lift-and-shift, replatform, modernization |
| Sizing baseline | vCPU, RAM, storage volume |
| Data and storage | Block, file, object, database engine and size |
| Availability topology | Single-zone, multi-zone, multi-region |
| Disaster recovery | Required (yes/no), RTO, RPO, pattern |
| Backup | Scope, frequency, retention |
| Security and compliance | Frameworks, key management, IAM, perimeter isolation |
| Observability | Logging, monitoring, audit |
| Hybrid connectivity | VPN, Direct Link, Transit Gateway, bandwidth |
| Migration | Mechanism, waves, dual-run |
| Service preferences | Preferred or prohibited IBM Cloud services |

---

## 4. Status values

| Status | Meaning |
|---|---|
| Found | A specific value is stated |
| Partial | Mentioned without a usable value (for example "high availability" with no SLA, or "Europe" with no region) |
| Missing | Not mentioned, blank, `TBD`, or an unfilled template placeholder such as `[e.g. ...]` |
| Not stated | Optional topic with no mention (no gap raised) |

---

## 5. Verdict rules

| Verdict | Condition | Action |
|---|---|---|
| READY | R1-R4 all `Found` | Continue to requirement indexing |
| READY WITH GAPS | No required topic `Missing`, at least one `Partial` | Ask one gap question per turn for each `Partial` topic, then re-evaluate |
| NOT READY | Any required topic `Missing` | Ask for the missing content or a richer file; hold design work |

Re-evaluate after every answer and record each answer as a `Customer` statement. When the user
chooses to proceed with a topic still `Partial`, label any design choice that depends on it
`Recommended` in the Details line of the component.

---

## 6. Readiness table format

```markdown
| Topic | Status | Value found | Source |
|---|---|---|---|
| R1 Workload and platform | Found | Order portal, x86 VMs | "Workload: Order portal" (line 24) |
| R2 Target region | Partial | "Europe" | line 31 |
| R3 Functional need | Found | Migrate portal and DB to IBM Cloud | line 12 |
| R4 Quantified NFR | Missing | — | — |
| Disaster recovery | Not stated | — | — |

Verdict: NOT READY — R4 is missing.
```

After the table, state the counts of Found, Partial, Missing, and Not stated topics.

---

## 7. Gap questions

Ask one question per turn, offering 2-4 options where well-known alternatives exist.

| Topic | Question |
|---|---|
| R1 | "Which workload should the architecture cover, and does it run on x86 virtual servers, containers, bare metal, or Power (AIX, IBM i, SAP HANA)?" |
| R2 | "Which IBM Cloud region should host it, for example us-south (Dallas), eu-de (Frankfurt), eu-gb (London), or jp-tok (Tokyo)?" |
| R3 | "What must the solution do at minimum, for example host the application, migrate an existing system, or integrate with an on-premises system?" |
| R4 | "Which measurable target applies: an availability SLA (99.9%, 99.95%, 99.99%), a capacity or performance figure, or a compliance framework?" |

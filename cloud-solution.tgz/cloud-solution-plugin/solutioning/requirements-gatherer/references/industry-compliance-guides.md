# Industry Compliance & Regulatory Guides

Reference guide for identifying regulatory requirements, compliance frameworks, and security mandates during requirements gathering.

## Table of Contents
- [1. Regulatory Frameworks Overview](#1-regulatory-frameworks-overview)
- [2. Healthcare & Life Sciences (HIPAA / HITECH)](#2-healthcare--life-sciences-hipaa--hitech)
- [3. Financial Services (PCI-DSS / SOC 2 / FS Cloud)](#3-financial-services-pci-dss--soc-2--fs-cloud)
- [4. Data Privacy & Sovereignty (GDPR / CCPA / Data Residency)](#4-data-privacy--sovereignty-gdpr--ccpa--data-residency)
- [5. Public Sector & Federal (FedRAMP / ISO 27001)](#5-public-sector--federal-fedramp--iso-27001)

---

## 1. Regulatory Frameworks Overview

When users indicate an industry or compliance mandate, map the mandatory requirements to cloud architecture dimensions:

| Framework | Core Focus | Mandatory Architectural Dimensions |
|---|---|---|
| **HIPAA** | Protected Health Information (PHI) | End-to-end encryption, BAA agreement, comprehensive audit trail, strict RBAC |
| **PCI-DSS v4.0** | Cardholder Data Environment (CDE) | Network micro-segmentation, dedicated key management, immutable audit logging |
| **FS Cloud** | Financial Services regulations | Reference architecture controls, Keep Your Own Key (KYOK), posture monitoring |
| **GDPR / EU Sovereignty** | Personal Data Privacy | In-region data residency (e.g. Frankfurt/eu-de), data subject deletion hooks, encryption |
| **FedRAMP / Public Sector** | High security government data | FIPS 140-2/3 validation, dedicated hardware options, rigorous vulnerability scans |
| **SOC 2 Type II / ISO 27001** | Security, availability, confidentiality | Centralized SIEM integration, change management logging, automated backups |

---

## 2. Healthcare & Life Sciences (HIPAA / HITECH)

Gather specific requirements when handling electronic Protected Health Information (ePHI):
- **Business Associate Agreement (BAA)**: Verify requirement for an executed IBM Cloud BAA.
- **Data in Transit**: Enforce TLS 1.2+ across all external and internal microservice communication.
- **Data at Rest**: Require AES-256 encryption across all object storage, block volumes, and databases.
- **Audit Logging**: Confirm retention duration for access and authentication audit logs (minimum 6 years recommended for HIPAA records).
- **Access Control**: Enforce multi-factor authentication (MFA) and least-privilege IAM roles.

---

## 3. Financial Services (PCI-DSS / SOC 2 / FS Cloud)

Gather specific requirements when processing payments or financial transactions:
- **Scope Isolation**: Define exact Cardholder Data Environment (CDE) boundaries to minimize compliance audit scope.
- **Key Management**: Determine key custody level — Customer-Managed (Key Protect) vs Hardware Security Module / Keep Your Own Key (Hyper Protect Crypto Services).
- **Network Micro-segmentation**: Enforce private endpoints, security group restrictions with zero open public ports to database tiers.
- **Vulnerability & Compliance Scanning**: Confirm need for automated compliance scanning and Workload Protection posture monitoring.

---

## 4. Data Privacy & Sovereignty (GDPR / CCPA / Data Residency)

Gather specific geographic and privacy constraints:
- **Data Sovereignty Region**: Confirm primary region (e.g., `eu-de` Frankfurt, `eu-gb` London, `ca-tor` Toronto, `jp-tok` Tokyo, `us-south` Dallas).
- **Cross-Border Transfers**: Identify restrictions on replicating backups or telemetry data outside sovereign borders.
- **Right to Erasure / Right to Access**: Verify requirements for data lifecycle policies and cryptographic erasure mechanisms.
- **PII Tokenization & Masking**: Check if database fields containing Personally Identifiable Information (PII) require client-side tokenization.

---

## 5. Public Sector & Federal (FedRAMP / ISO 27001)

Gather high-assurance security specifications:
- **Cryptographic Standards**: Verify FIPS 140-2 / FIPS 140-3 cryptographic module compliance.
- **Boundary Controls**: Capture requirements for Context-Based Restrictions (CBR) limiting access to specific corporate IP ranges and trusted VPCs.
- **Configuration & Change Audit**: Verify continuous activity tracking through IBM Cloud Activity Tracker / Cloud Logs integration.

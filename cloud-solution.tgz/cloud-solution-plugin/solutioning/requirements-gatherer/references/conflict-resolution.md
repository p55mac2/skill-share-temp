# Conflict Detection & Trade-off Resolution

Methodology for identifying contradictions, evaluating technical trade-offs, and negotiating resolutions during requirements gathering.

## Table of Contents
- [1. Common Requirement Contradictions](#1-common-requirement-contradictions)
- [2. The 4-Step Conflict Resolution Protocol](#2-the-4-step-conflict-resolution-protocol)
- [3. Trade-off Matrix & Decision Patterns](#3-trade-off-matrix--decision-patterns)
- [4. Recording Resolved Conflicts in the Record](#4-recording-resolved-conflicts-in-the-record)

---

## 1. Common Requirement Contradictions

Review gathered requirements against these frequent architectural conflicts:

| Requirement A | Requirement B | Architectural Conflict | Resolution Strategy |
|---|---|---|---|
| Complete network isolation (air-gapped / private endpoints only) | External webhooks / public client ingestion | Ingress path blocked by total private isolation | Implement IBM Cloud Internet Services (CIS) or API Gateway in a dedicated ingress DMZ with WAF and CBR |
| Zero RPO across distant geographic regions | Sub-10ms transaction latency SLA | Synchronous replication over wide-area networks introduces unavoidable physical network latency | Adopt semi-synchronous or asynchronous replication, or establish multi-zone region (MZR) synchronous clusters |
| Strict budget ceiling (< $500/mo) | High Availability Multi-Region Active-Active with 99.99% SLA | Multi-region redundant infrastructure and global load balancing exceed low budget tiers | Prioritize Multi-Zone Region (MZR) HA within a single region, backed by Pilot Light DR in a secondary region |
| Strict PCI-DSS / HIPAA compliance | Rapid prototype deployment without central landing zone governance | Unmanaged environments lack required audit trails, key management, and security controls | Utilize IBM Cloud Framework for Financial Services or standard Terraform Landing Zone templates |
| Extreme compute burstability | Fixed non-scaling budget constraints | Uncapped auto-scaling risks cost overruns | Implement hard budget alerts, max worker node caps, and burstable container instance tiers |

---

## 2. The 4-Step Conflict Resolution Protocol

Execute this structured sequence whenever contradictory or ambiguous requirements emerge:

### Step 1: Isolate the Contradiction
State clearly which two or more requirements are in tension. Cite the specific numbers, SLAs, or policies that clash.

### Step 2: Explain the Technical Constraint
Explain the underlying engineering, physical, or regulatory principle causing the clash (e.g., CAP theorem, speed of light in fiber, compliance segregation mandates).

### Step 3: Present Viable Options with Trade-offs
Offer 2–3 concrete alternatives. For each option, clearly present:
- What is prioritized (e.g., lower latency vs zero data loss)
- What is compromised (e.g., higher cost vs relaxed RPO)
- Recommended option with architectural rationale

### Step 4: Secure Explicit User Selection
Request user confirmation of the chosen trade-off before marking the requirement as confirmed. If the user requests an architectural recommendation, provide the recommended path and seek affirmative approval.

---

## 3. Trade-off Matrix & Decision Patterns

Use these established trade-off patterns to guide users through standard cloud compromises:

### Pattern A: Availability vs Cost
- **High Budget / Ultra HA**: Multi-Region Active-Active with Cloud Internet Services (CIS) GLB (99.99% uptime).
- **Balanced Cost / Standard HA**: Single Region Multi-Zone (MZR) with ALB across 3 availability zones (99.95% uptime).
- **Cost-Optimized / Basic HA**: Single Zone deployment with automated snapshot backups and cold recovery (99.0% uptime).

### Pattern B: Recovery Speed (RTO/RPO) vs Infrastructure Complexity
- **Tier 1 (Critical)**: RTO < 15 min, RPO ≈ 0. Synchronous storage replication across MZR, warm standby in secondary region.
- **Tier 2 (Essential)**: RTO < 4 hrs, RPO < 1 hr. Scheduled automated backups to Cloud Object Storage with cross-region replication.
- **Tier 3 (Dev/Test)**: RTO < 24 hrs, RPO < 24 hrs. Infrastructure as Code redeployment from Git repository and daily snapshots.

### Pattern C: Security Control vs Developer Agility
- **Strict Governance**: Dedicated HSM (Hyper Protect Crypto Services), Context-Based Restrictions (CBR), centralized Bastion/VPE, private endpoints.
- **Standard Enterprise**: Key Protect customer-managed keys, Security Groups, IAM Access Groups, private endpoints with Transit Gateway.
- **Agile Development**: IBM-managed encryption, IAM service credentials, Code Engine serverless deployment with managed certificates.

---

## 4. Recording Resolved Conflicts in the Record

Document every resolved conflict in the **Confirmed Conflicts & Resolutions** section of the Requirements Record:
- **Conflict Item**: Summary of the competing requirements.
- **Root Constraint**: Engineering, financial, or compliance reason.
- **Agreed Resolution**: Chosen option and agreed SLA/configuration.
- **User Approval**: Explicit confirmation status.

# Elicitation Framework & Question Taxonomy

Structured question sequences and adaptive interview paths for capturing cloud workload requirements. All questions are asked **one at a time** — load this reference to select the next question for the current topic, then return to the conversation and wait for the answer.

## Table of Contents
- [1. Persona-Adaptive Questioning Paths](#1-persona-adaptive-questioning-paths)
- [2. Workload Archetype Question Sequences](#2-workload-archetype-question-sequences)
- [3. Non-Functional Requirements Deep-Dive](#3-non-functional-requirements-deep-dive)
- [4. Data & State Inventory](#4-data--state-inventory)
- [5. Integration & Connectivity Checklist](#5-integration--connectivity-checklist)

---

## 1. Persona-Adaptive Questioning Paths

Adapt the inquiry style based on the user's organization type and architectural maturity:

| Persona | Focus Areas | Questioning Tone & Depth |
|---|---|---|
| **Startup / Scaleup** | Time-to-market, monthly spend cap, managed services, lean operations | High level on infra; focus on core app stack, scaling triggers, and budget boundaries |
| **Enterprise IT** | Governance, IAM, landing zones, VPC isolation, existing IdP integration | Detailed on account structures, security policies, compliance audits, change control |
| **Regulated (FSI / Health / Gov)** | Compliance frameworks, key management (BYOK/KYOK), audit logs, air-gapped networks | Rigorous on regulatory boundaries, data residency, HSM requirements, and retention |
| **Migration Team** | Current source inventory, RTO/RPO, cutover windows, network throughput | Deep dive on source VM/LPAR specs, storage capacity, database engines, dependencies |

---

## 2. Workload Archetype Question Sequences

Ask each question in the sequence below, one per turn, after confirming the workload platform in Phase 1.

### A. Web / API / Microservices (Cloud-Native)
Ask in order — one question per turn:
1. What is the primary runtime? Offer options: Containerized on IKS/ROKS, Serverless on Code Engine, or Virtual Servers.
2. What are the peak and baseline request volumes, and is auto-scaling expected?
3. Are session states externalized — for example using Redis or Databases for PostgreSQL?
4. What are the ingress requirements? Offer options: Public internet, private enterprise intranet, or API Gateway.

### B. Core Enterprise & Legacy Systems (VMs / PowerVS)
Ask in order — one question per turn:
1. Does this workload require IBM Power (AIX, IBM i, or SAP HANA on Power)?
2. What are the specific vCPU count, RAM (GB), and storage IOPS of the existing instances?
3. What operating system version and license model apply? Offer options: BYOL or IBM-provided.
4. Are there clustering or high-availability software layers in use? Offer options: PowerHA, HACMP, Pacemaker, or none.

### C. Data Platforms & Analytics
Ask in order — one question per turn:
1. What database engines are in scope? Offer options: Db2, PostgreSQL, MongoDB, Redis, Cloudant, Oracle, or other.
2. Is this workload primarily transactional (OLTP), analytical (OLAP), or a mix of both?
3. What is the total data volume, the daily ingest rate, and the required retention period?
4. Is event streaming or pub/sub messaging required? Offer options: Event Streams (Apache Kafka), IBM MQ, or neither.

### D. AI & Machine Learning Workloads
Ask in order — one question per turn:
1. Are models being trained from scratch, fine-tuned, or consumed via API endpoints only?
2. What are the inference latency and concurrency SLA targets?
3. What model runtime or framework is targeted? Offer options: watsonx.ai, vLLM, Triton, Red Hat OpenShift AI, or other.
4. Are dedicated GPUs required, and if so what precision and VRAM specifications apply?

---

## 3. Non-Functional Requirements Deep-Dive

Ask each question below as a separate turn, in order. Each bullet is one question — do not combine.

### Availability & High Availability (HA)
1. What is the target uptime percentage? Offer options: 99.9%, 99.95%, or 99.99%.
2. What availability zone strategy is required? Offer options: Single-zone, Multi-zone region, or Cross-region failover.
3. Is there a required maintenance window, and are zero-downtime deployments expected?

### Business Continuity & Disaster Recovery (BC/DR)
1. What is the Recovery Time Objective (RTO) — the maximum downtime tolerated during an outage?
2. What is the Recovery Point Objective (RPO) — the maximum data loss tolerated, measured in time?
3. Which DR pattern is preferred? Offer options: Active-Active, Active-Passive (Warm Standby), or Pilot Light.

### Backup & Retention
1. How frequently should snapshots and database transaction log backups run?
2. What retention periods are required? Ask for daily, weekly, monthly, and yearly archive durations.
3. Are there geographic storage requirements such as immutable object storage or cross-region replication?

### Performance & Scalability
1. What are the throughput targets in transactions per second or requests per second?
2. What are the latency ceilings for p95 and p99 response times (in milliseconds)?
3. What storage performance is needed? Ask for IOPS tier, read/write ratio, and throughput in MB/s.

---

## 4. Data & State Inventory

For each distinct data store, establish:
- **Classification**: Public, Internal, Confidential, Restricted (PII, PHI, Cardholder data)
- **Encryption**: Standard IBM-managed keys, Bring Your Own Key (multi-tenant Key Protect), or Keep Your Own Key (dedicated Key Protect)
- **Residency**: Specific country or geopolitical region where data must remain at rest and in transit
- **Lifecycle**: Archival schedule and automated tiering to cold/archive storage classes

---

## 5. Integration & Connectivity Checklist

Establish network boundaries and external connections:
- **Hybrid Connectivity**: Dedicated Direct Link 2.0, IPsec Site-to-Site VPN, or Software-defined WAN
- **Routing & Isolation**: Transit Gateway for interconnecting VPCs and classic infrastructure, Context-Based Restrictions (CBR) for service control
- **Identity Federation**: SAML 2.0 / OpenID Connect federation with external identity providers (Azure AD, Okta, Ping, Active Directory)

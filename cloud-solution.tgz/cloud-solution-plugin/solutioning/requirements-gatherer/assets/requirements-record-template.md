# Confirmed Requirements Record (requirements.md)

Authoritative requirements baseline for downstream architecture, sizing, provisioning, and validation workflows.

---

## 1. Customer & Business Context

- **Customer / Organisation Name**: [e.g. Acme Financial / Global Logistics Inc.]
- **Industry Sector**: [e.g. Banking & Financial Services / Healthcare & Life Sciences / Retail / Public Sector]
- **Organisation Scale**: [Startup (<50) / Mid-Market (50–5000) / Enterprise (>5000)]
- **Primary Business Objectives**: [e.g. Cost reduction, cloud modernization, regulatory compliance, rapid market expansion]
- **Project Scope & Timeline**: [Target completion date, phased milestones, proof-of-concept windows]
- **Budgetary Boundaries / FinOps Priorities**: [Target monthly budget, reserved capacity preferences, cost allocation tags]

---

## 2. Workload Inventory & Target Platforms

> Repeat for each distinct workload or system subsystem.

### Workload: [Workload Name / Component]
- **Workload Description**: [Functional purpose, business criticality, end-user community]
- **Platform Architecture**: [x86 Virtual Servers / Containers (IKS/ROKS/Code Engine) / Bare Metal / Power LPAR (AIX / IBM i / SAP HANA)]
- **Transformation Strategy**: [Greenfield / Lift-and-Shift / Replatform / Cloud-Native Refactor]
- **Current Hosting Location**: [On-Premises Datacenter / Co-location / AWS / Azure / GCP / Existing IBM Cloud Account]
- **Compute Sizing Baseline**: [Current vCPUs, RAM, storage volume, peak utilization metrics]
- **Software & OS Stack**: [Operating system, runtime versions, database engines, commercial licensing BYOL vs cloud-provided]
- **Upstream & Downstream Dependencies**: [Connected APIs, identity providers, legacy mainframes, message brokers]

---

## 3. Data & Storage Specifications

- **Data Classifications in Scope**: [Public / Internal / Confidential / Restricted (PII, PHI, PCI Cardholder Data)]
- **Storage Types & Capacities**:
  - Block Storage (VPC Block / PowerVS Tier): [Capacity in GB/TB, IOPS tier, attachment mode]
  - File Storage (VPC File / NFS): [Capacity in GB/TB, IOPS tier, share protocols]
  - Object Storage (IBM Cloud Object Storage): [Capacity in TB/PB, storage class (Standard/Vault/Cold/Smart), resiliency (Cross-Region/Regional/Single Site)]
- **Database Systems**: [Engine type, version, clustering model, total database size, transaction rate]
- **Data Residency & Sovereignty Mandates**: [Specific country, region, or jurisdiction where data must reside]
- **Key Management & Encryption Custody**: [IBM-Managed Keys / Customer-Managed Keys (Key Protect) / Keep Your Own Key (HPCS HSM)]

---

## 4. Non-Functional Requirements (NFR)

### Availability & Resiliency
- **Target Uptime SLA**: [e.g. 99.9% (3 nines), 99.95%, 99.99% (4 nines)]
- **Deployment Topology**: [Single-Zone / Multi-Zone Region (MZR) / Multi-Region Cross-Geographic]
- **Maintenance Tolerance**: [Zero-downtime rolling upgrades / Scheduled off-peak maintenance window]

### Business Continuity & Disaster Recovery (BC/DR)
- **Disaster Recovery Required?**: [Yes / No]
- **Recovery Time Objective (RTO)**: [Maximum allowable downtime during disaster]
- **Recovery Point Objective (RPO)**: [Maximum allowable data loss window]
- **DR Architecture Pattern**: [Active-Active / Warm Standby (Active-Passive) / Pilot Light / Cold Restore]

### Backup & Retention
- **Backup Scope**: [Databases, virtual server boot/data volumes, container persistent volumes, object storage]
- **Frequency**: [Hourly database transaction logs / Daily volume snapshots / Weekly full exports]
- **Retention Schedule**: [30-day daily / 12-month weekly / 7-year regulatory compliance archives]
- **Immutability & Air-Gapping**: [WORM / Retention lock / Cross-account backup vault]

### Performance & Scalability
- **Throughput Expectations**: [Requests per second, queries per second, concurrent active users]
- **Latency Tolerances**: [End-user p95/p99 response time limits]
- **Scalability Mechanism**: [Horizontal auto-scaling / Vertical dynamic resizing / Scheduled burst capacity]

### Security, Compliance & Observability
- **Regulatory Frameworks**: [PCI-DSS v4.0 / HIPAA / GDPR / FedRAMP / SOC 2 / ISO 27001 / FS Cloud]
- **Network Perimeter Isolation**: [Private endpoints only / Context-Based Restrictions (CBR) / Public Ingress via WAF/CIS]
- **Identity & Access Management**: [IBM Cloud IAM / Federated IdP (Azure AD, Okta, Ping) / App ID]
- **Observability Standards**: [Centralized IBM Cloud Logs / Cloud Monitoring / Activity Tracker / Enterprise SIEM]

---

## 5. Migration & Network Connectivity

- **Migration Mechanism**: [Live VM replication / Offline data seeding / Containerized CI/CD deployment / Database replication]
- **Hybrid Network Connectivity**: [Direct Link 2.0 Dedicated / Direct Link Connect / Site-to-Site IPsec VPN / Transit Gateway]
- **Bandwidth Requirements**: [Dedicated throughput e.g. 1 Gbps, 5 Gbps, 10 Gbps]
- **Interim Dual-Run Architecture**: [Requirement for hybrid communication during multi-month migration phases]

---

## 6. Target IBM Cloud Environment

- **Target Deployment Region(s)**: [e.g. us-south (Dallas), us-east (Washington DC), eu-de (Frankfurt), eu-gb (London), jp-tok (Tokyo)]
- **Account & Landing Zone Status**: [Existing enterprise account with Enterprise Hierarchy / Existing Terraform Landing Zone / Greenfield setup]
- **Service Preferences & Constraints**: [Preferred IBM Cloud services or corporate technology restrictions]

---

## 7. Confirmed Conflicts & Trade-off Decisions

| # | Conflict / Ambiguity Identified | Engineering / Business Trade-off | Agreed Resolution | User Confirmation |
|---|---|---|---|---|
| 1 | [e.g. High HA vs strict budget] | [Single MZR vs Cross-Region active-active] | [MZR Multi-Zone with Pilot Light DR] | Confirmed |

---

## 8. Requirements Completeness Gate Status

- **Status**: [PASSED / IN-PROGRESS]
- **Review Date**: [YYYY-MM-DD]
- **Stakeholder Confirmation**: [User confirmed complete with no additional changes]

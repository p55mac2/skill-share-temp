# Requirements Completeness Gate Checklist

Verification gate to confirm requirements are comprehensive, unambiguous, and formally agreed upon before architecture design or provisioning begins.

---

## Completeness Gate Checklist

Every item below must be verified and checked before passing the requirements record to downstream design skills:

```
[ ] Customer identity, industry sector, and organization scale confirmed
[ ] Primary business drivers and timeline objectives established
[ ] Every workload identified with platform type (x86 VM, Container, Bare Metal, Power LPAR)
[ ] Transformation intent per workload defined (Greenfield, Lift-and-Shift, Replatform, Modernize)
[ ] Sizing baselines, CPU, RAM, and storage specifications recorded
[ ] Availability SLA and HA deployment topology established (or explicitly marked basic/none)
[ ] Disaster recovery requirements, RTO, and RPO defined (or explicitly marked not required)
[ ] Backup frequency, retention periods, and immutability targets established
[ ] Security, encryption custody (BYOK/KYOK), and compliance frameworks identified
[ ] Network isolation, public ingress DMZ, and hybrid connectivity (Direct Link/VPN) defined
[ ] Target IBM Cloud region(s) and existing account/landing zone status confirmed
[ ] FinOps budget constraints, cost allocation, and tagging requirements recorded
[ ] All architectural conflicts and trade-offs explicitly identified, resolved, and confirmed
[ ] Confirmed Requirements Record saved to requirements.md and accepted by user
```

---

## Gate Passage Rules

1. **All Checkboxes Satisfied**: Every item must either have confirmed values or an explicit note stating it is not applicable (e.g. `[x] DR requirement: Explicitly not required for dev/test`).
2. **Explicit Stakeholder Sign-Off**: The user must acknowledge the Confirmed Requirements Record before downstream handoff occurs.
3. **Traceability Guarantee**: Downstream skills (`ibmcloud-solutioner`, `cloud-architect`, `ibm-cloud-terraform`) consume the populated `requirements.md` file as the authoritative source of truth.
